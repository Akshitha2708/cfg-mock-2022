import image from './imgs/1.jpg';
function App() {
  let data="akshitha"
  let obj={
    name:"abcd",
    pincode:500011
  }

  return (
    //one element to be returned
    <div className="text-center">
      <img src={image}></img>
      <h1>welocme to react app</h1>
      <h2>name {data}</h2>
      <h3>pincode{obj.pincode}</h3>
      <img src=""></img>
    </div>
  );
}

export default App;
